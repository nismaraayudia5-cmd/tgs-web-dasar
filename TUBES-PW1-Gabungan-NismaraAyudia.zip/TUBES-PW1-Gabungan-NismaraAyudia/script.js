/* ===== Pengganti website (tiket.com / Canva / Tokopedia) ===== */
const namaSitus = { tiket: 'tiket.com', canva: 'Canva', toped: 'Tokopedia' };
const sw = document.querySelectorAll('#switch button');
sw.forEach(b => b.addEventListener('click', () => {
  const s = b.dataset.s;
  sw.forEach(x => x.classList.toggle('on', x === b));
  document.querySelectorAll('.panel').forEach(p => p.classList.toggle('on', p.id === s));
  document.body.className = s;
  document.getElementById('logo').textContent = namaSitus[s];
  document.title = namaSitus[s] + ' - TUBES PW1';
  window.scrollTo({ top: 0 });
}));

/* ===== tiket.com ===== */
const tkTabs = document.querySelectorAll('#tkTabs button');
let tkMode = 'Pesawat';
tkTabs.forEach(b => b.addEventListener('click', () => {
  tkTabs.forEach(x => x.classList.remove('on'));
  b.classList.add('on');
  tkMode = b.dataset.t;
  document.getElementById('tkKeLabel').textContent = tkMode === 'Hotel' ? 'Kota / hotel' : 'Ke';
}));
document.getElementById('tkForm').addEventListener('submit', e => {
  e.preventDefault();
  const dari = document.getElementById('tkDari').value.trim();
  const ke = document.getElementById('tkKe').value.trim();
  const tgl = document.getElementById('tkTgl').value;
  const out = document.getElementById('tkHasil');
  if (!ke || !tgl) { out.textContent = 'Isi tujuan dan tanggal dulu.'; return; }
  out.textContent = tkMode === 'Hotel'
    ? 'Mencari hotel di ' + ke + ' untuk ' + tgl + '...'
    : 'Mencari ' + tkMode.toLowerCase() + ' ' + dari + ' ke ' + ke + ' pada ' + tgl + '...';
});

/* ===== Canva ===== */
const cvOut = document.getElementById('cvHasil');
document.getElementById('cvForm').addEventListener('submit', e => {
  e.preventDefault();
  const q = document.getElementById('cvQ').value.trim();
  cvOut.textContent = q ? 'Menampilkan template untuk "' + q + '"...' : 'Ketik kata kunci template dulu.';
});
document.querySelectorAll('#cvCats div').forEach(d => d.addEventListener('click', () => {
  cvOut.textContent = 'Membuat desain baru: ' + d.textContent.trim() + '...';
  window.scrollTo({ top: 0, behavior: 'smooth' });
}));

/* ===== Tokopedia ===== */
const produk = [
  { n: 'Headphone Nirkabel', k: 'elektronik', h: 289000, e: '🎧' },
  { n: 'Kaos Polos Katun', k: 'fashion', h: 59000, e: '👕' },
  { n: 'Lampu Meja LED', k: 'rumah', h: 85000, e: '💡' },
  { n: 'Sepatu Lari Ringan', k: 'olahraga', h: 350000, e: '👟' },
  { n: 'Power Bank 10.000 mAh', k: 'elektronik', h: 149000, e: '🔋' },
  { n: 'Tas Ransel Kampus', k: 'fashion', h: 175000, e: '🎒' },
  { n: 'Rak Buku Minimalis', k: 'rumah', h: 220000, e: '📚' },
  { n: 'Matras Yoga', k: 'olahraga', h: 99000, e: '🧘' }
];
const tpList = document.getElementById('tpList');
let tpKat = 'semua', tpKata = '';
const rp = n => 'Rp ' + n.toLocaleString('id-ID');
function tampilProduk() {
  const data = produk.filter(p =>
    (tpKat === 'semua' || p.k === tpKat) && p.n.toLowerCase().includes(tpKata));
  tpList.innerHTML = data.length
    ? data.map(p => '<div class="card"><div class="img">' + p.e + '</div><div class="t"><h3>' +
        p.n + '</h3><div class="price">' + rp(p.h) + '</div><small>Gratis ongkir</small></div></div>').join('')
    : '<p>Produk tidak ditemukan. Coba kata kunci lain.</p>';
}
document.getElementById('tpForm').addEventListener('submit', e => {
  e.preventDefault();
  tpKata = document.getElementById('tpQ').value.trim().toLowerCase();
  document.getElementById('tpHasil').textContent = tpKata ? 'Hasil untuk "' + tpKata + '"' : '';
  tampilProduk();
  document.getElementById('tpProduk').scrollIntoView({ behavior: 'smooth' });
});
document.querySelectorAll('#tpCats div').forEach(d => d.addEventListener('click', () => {
  tpKat = d.dataset.k;
  tampilProduk();
}));
tampilProduk();
