# TUBES PW1 - Nismara Ayudia

Gabungan tiruan tampilan **tiket.com**, **Canva**, dan **Tokopedia** dalam satu halaman. Ganti website lewat tombol di header.

- Nama: Nismara Ayudia
- NPM: 5520125056
- Mata kuliah: Pemrograman Web 1

## Teknologi
HTML, CSS, JavaScript (tanpa framework).

## Fitur
- Tombol pengganti website di header (warna dan judul ikut berubah)
- tiket.com: tab Pesawat/Hotel/Kereta dan form pencarian
- Canva: pencarian template dan pilihan jenis desain
- Tokopedia: pencarian produk dan filter kategori

## Cara menjalankan
Buka `index.html` di browser, atau aktifkan GitHub Pages (Settings > Pages > branch `main`).

## Struktur
```
index.html
style.css
script.js
```

*Proyek ini tiruan untuk tugas kuliah dan tidak berafiliasi dengan situs aslinya.*
